import 'package:flutter/material.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  bool _WeeklySub = true;
  bool get WeeklySub => _WeeklySub;
  set WeeklySub(bool value) {
    _WeeklySub = value;
  }

  bool _MonthlySub = false;
  bool get MonthlySub => _MonthlySub;
  set MonthlySub(bool value) {
    _MonthlySub = value;
  }

  bool _isSubscribed = false;
  bool get isSubscribed => _isSubscribed;
  set isSubscribed(bool value) {
    _isSubscribed = value;
  }
}
