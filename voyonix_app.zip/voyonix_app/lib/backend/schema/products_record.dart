import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ProductsRecord extends FirestoreRecord {
  ProductsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "CatRef_ID" field.
  DocumentReference? _catRefID;
  DocumentReference? get catRefID => _catRefID;
  bool hasCatRefID() => _catRefID != null;

  // "Image" field.
  String? _image;
  String get image => _image ?? '';
  bool hasImage() => _image != null;

  // "PhoneNumber" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "Address" field.
  String? _address;
  String get address => _address ?? '';
  bool hasAddress() => _address != null;

  // "Clock" field.
  String? _clock;
  String get clock => _clock ?? '';
  bool hasClock() => _clock != null;

  // "Descriprion" field.
  String? _descriprion;
  String get descriprion => _descriprion ?? '';
  bool hasDescriprion() => _descriprion != null;

  // "Tag_for_search" field.
  String? _tagForSearch;
  String get tagForSearch => _tagForSearch ?? '';
  bool hasTagForSearch() => _tagForSearch != null;

  // "Map_Loacation" field.
  LatLng? _mapLoacation;
  LatLng? get mapLoacation => _mapLoacation;
  bool hasMapLoacation() => _mapLoacation != null;

  // "Image2" field.
  String? _image2;
  String get image2 => _image2 ?? '';
  bool hasImage2() => _image2 != null;

  // "Imgae3" field.
  String? _imgae3;
  String get imgae3 => _imgae3 ?? '';
  bool hasImgae3() => _imgae3 != null;

  // "visibility" field.
  bool? _visibility;
  bool get visibility => _visibility ?? false;
  bool hasVisibility() => _visibility != null;

  void _initializeFields() {
    _name = snapshotData['Name'] as String?;
    _catRefID = snapshotData['CatRef_ID'] as DocumentReference?;
    _image = snapshotData['Image'] as String?;
    _phoneNumber = snapshotData['PhoneNumber'] as String?;
    _address = snapshotData['Address'] as String?;
    _clock = snapshotData['Clock'] as String?;
    _descriprion = snapshotData['Descriprion'] as String?;
    _tagForSearch = snapshotData['Tag_for_search'] as String?;
    _mapLoacation = snapshotData['Map_Loacation'] as LatLng?;
    _image2 = snapshotData['Image2'] as String?;
    _imgae3 = snapshotData['Imgae3'] as String?;
    _visibility = snapshotData['visibility'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Products');

  static Stream<ProductsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ProductsRecord.fromSnapshot(s));

  static Future<ProductsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ProductsRecord.fromSnapshot(s));

  static ProductsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ProductsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ProductsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ProductsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ProductsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ProductsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createProductsRecordData({
  String? name,
  DocumentReference? catRefID,
  String? image,
  String? phoneNumber,
  String? address,
  String? clock,
  String? descriprion,
  String? tagForSearch,
  LatLng? mapLoacation,
  String? image2,
  String? imgae3,
  bool? visibility,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Name': name,
      'CatRef_ID': catRefID,
      'Image': image,
      'PhoneNumber': phoneNumber,
      'Address': address,
      'Clock': clock,
      'Descriprion': descriprion,
      'Tag_for_search': tagForSearch,
      'Map_Loacation': mapLoacation,
      'Image2': image2,
      'Imgae3': imgae3,
      'visibility': visibility,
    }.withoutNulls,
  );

  return firestoreData;
}

class ProductsRecordDocumentEquality implements Equality<ProductsRecord> {
  const ProductsRecordDocumentEquality();

  @override
  bool equals(ProductsRecord? e1, ProductsRecord? e2) {
    return e1?.name == e2?.name &&
        e1?.catRefID == e2?.catRefID &&
        e1?.image == e2?.image &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.address == e2?.address &&
        e1?.clock == e2?.clock &&
        e1?.descriprion == e2?.descriprion &&
        e1?.tagForSearch == e2?.tagForSearch &&
        e1?.mapLoacation == e2?.mapLoacation &&
        e1?.image2 == e2?.image2 &&
        e1?.imgae3 == e2?.imgae3 &&
        e1?.visibility == e2?.visibility;
  }

  @override
  int hash(ProductsRecord? e) => const ListEquality().hash([
        e?.name,
        e?.catRefID,
        e?.image,
        e?.phoneNumber,
        e?.address,
        e?.clock,
        e?.descriprion,
        e?.tagForSearch,
        e?.mapLoacation,
        e?.image2,
        e?.imgae3,
        e?.visibility
      ]);

  @override
  bool isValidKey(Object? o) => o is ProductsRecord;
}
