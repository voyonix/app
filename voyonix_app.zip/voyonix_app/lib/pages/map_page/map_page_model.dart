import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/modal_map/modal_map_widget.dart';
import 'map_page_widget.dart' show MapPageWidget;
import 'package:flutter/material.dart';

class MapPageModel extends FlutterFlowModel<MapPageWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for GoogleMap widget.
  LatLng? googleMapsCenter;
  final googleMapsController = Completer<GoogleMapController>();
  // Model for ModalMap component.
  late ModalMapModel modalMapModel;

  @override
  void initState(BuildContext context) {
    modalMapModel = createModel(context, () => ModalMapModel());
  }

  @override
  void dispose() {
    modalMapModel.dispose();
  }
}
