import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'subscribe_widget.dart' show SubscribeWidget;
import 'package:flutter/material.dart';

class SubscribeModel extends FlutterFlowModel<SubscribeWidget> {
  ///  State fields for stateful widgets in this page.

  // Stores action output result for [RevenueCat - Purchase] action in Container widget.
  bool? didpurchase;
  // Stores action output result for [RevenueCat - Purchase] action in Container widget.
  bool? didpurchase2;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
