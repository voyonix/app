import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'products_page_widget.dart' show ProductsPageWidget;
import 'package:flutter/material.dart';

class ProductsPageModel extends FlutterFlowModel<ProductsPageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
