import '/flutter_flow/flutter_flow_util.dart';
import 'about_app_widget.dart' show AboutAppWidget;
import 'package:flutter/material.dart';

class AboutAppModel extends FlutterFlowModel<AboutAppWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
