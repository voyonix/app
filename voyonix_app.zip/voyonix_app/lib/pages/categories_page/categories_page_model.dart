import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'categories_page_widget.dart' show CategoriesPageWidget;
import 'package:flutter/material.dart';

class CategoriesPageModel extends FlutterFlowModel<CategoriesPageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
