import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'place_details_widget.dart' show PlaceDetailsWidget;
import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';

class PlaceDetailsModel extends FlutterFlowModel<PlaceDetailsWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Carousel widget.
  CarouselSliderController? carouselController;
  int carouselCurrentIndex = 1;

  // State field(s) for Expandable widget.
  late ExpandableController expandableExpandableController;

  // Stores action output result for [Custom Action - formatLatLngToGeoURI] action in Image widget.
  String? geo;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    expandableExpandableController.dispose();
  }
}
