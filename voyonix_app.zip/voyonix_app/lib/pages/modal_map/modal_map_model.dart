import '/flutter_flow/flutter_flow_util.dart';
import 'modal_map_widget.dart' show ModalMapWidget;
import 'package:flutter/material.dart';

class ModalMapModel extends FlutterFlowModel<ModalMapWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
