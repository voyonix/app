import '/flutter_flow/flutter_flow_util.dart';
import 'profile_page_comp_widget.dart' show ProfilePageCompWidget;
import 'package:flutter/material.dart';

class ProfilePageCompModel extends FlutterFlowModel<ProfilePageCompWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
