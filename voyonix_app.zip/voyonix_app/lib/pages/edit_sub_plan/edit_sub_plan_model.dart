import '/flutter_flow/flutter_flow_util.dart';
import 'edit_sub_plan_widget.dart' show EditSubPlanWidget;
import 'package:flutter/material.dart';

class EditSubPlanModel extends FlutterFlowModel<EditSubPlanWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
