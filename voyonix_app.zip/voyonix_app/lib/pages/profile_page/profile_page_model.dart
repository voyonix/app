import '/flutter_flow/flutter_flow_util.dart';
import '/pages/profile_page_comp/profile_page_comp_widget.dart';
import 'profile_page_widget.dart' show ProfilePageWidget;
import 'package:flutter/material.dart';

class ProfilePageModel extends FlutterFlowModel<ProfilePageWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for ProfilePageComp component.
  late ProfilePageCompModel profilePageCompModel;

  @override
  void initState(BuildContext context) {
    profilePageCompModel = createModel(context, () => ProfilePageCompModel());
  }

  @override
  void dispose() {
    profilePageCompModel.dispose();
  }
}
