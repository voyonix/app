package com.mycompany.qartalnext

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
